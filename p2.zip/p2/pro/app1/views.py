from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def new(request):
    return HttpResponse('Hellowwww'
                        '<a href=/index/>Index</a>')


def index(request):
    return render(request,template_name="index.html")