from django.contrib import admin
from .models import cart

# Register your models here.
admin.site.register(cart)