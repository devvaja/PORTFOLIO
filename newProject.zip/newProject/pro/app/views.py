import datetime

from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import *



# Create your views here.
def home(request):
    return HttpResponse("hii"
                        "<a href='/index/'>Go</a>")

def html(request):
    return render(request,'index.html')

def register(request):

    if request.method == 'POST':
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password']
        repeat_password=request.POST['repeat_password']


        if User.objects.filter(username=username):
            messages.error(request, 'Username already taken')
            return redirect('home')

        if User.objects.filter(email=email):
            messages.error(request,'email already exists')
            return redirect('home')

        if len(username)>10:

            messages.error(request,'username must be greater than 10')
            return redirect('home')

        if password != repeat_password:
            messages.error(request,'password not matched')
            return redirect('home')


        if not username.isalnum():
            messages.error(request,'userrname must be AlphaNumeric')
            return redirect('home')

        s=User.objects.create_user(username=username,email=email,password=password,)
        s.save()
        messages.success(request,"Account Created")

        return redirect('/login/')

    return render(request,'register.html')

def Login(request):
    if request.method == 'POST':
        username=request.POST['username']
        password=request.POST['password']

        user=authenticate(username=username,password=password)

        if user is not None:
            login(request, user)
            return redirect('/')
            # return redirect('/logout/')


        else:
            messages.error(request, 'unsuccesfull')
            return redirect('home')

    return render(request,'login.html')


def Logout(request):
    logout(request)
    return redirect('/')


def createProduct(request):
    if request.method == 'POST':
        name = request.POST['name']
        price = request.POST['price']
        description = request.POST['description']
        status = request.POST['status']
        # createDate = request.POST['createDate']
        image1 = request.FILES['image1']
        image2 = request.FILES['image2']
        quantity = request.POST['quantity']
        p = Product.objects.create(name=name,price=price,description=description,status=status,
                                   image1=image1,image2=image2,quantity=quantity)
        return redirect('/readProduct/')
        # return HttpResponse('Success')
    return render(request,'product.html')


def readProduct(request):
    p = Product.objects.all()
    return render(request,'readProduct.html',{'p':p})

def updateProduct(request,id):
    p = Product.objects.get(id=id)
    if request.method == 'POST':
        name = request.POST['name']
        price = request.POST['price']
        description = request.POST['description']
        status = request.POST['status']
        image1 = request.FILES['image1']
        image2 = request.FILES['image2']
        quantity = request.POST['quantity']
        p.name = name
        p.price = price
        p.description = description
        p.status = status
        p.image1 = image1
        p.image2 = image2
        p.quantity = quantity

        if img:
            p.image1=image1
            p.image2=image2
        p.save()
        return redirect("/readProduct/")
    return render(request,'updateProduct.html',{'p':p})

def deleteProduct(request,pid):
    p = Product.objects.get(id=pid)
    p.delete()
    return redirect('/readProduct/')

def addProduct(request):
    return redirect('/product/')

def viewProduct(request,id):
    p=Product.objects.get(id=id)
    i1 = p.image1
    i2 = p.image2
    name = p.name
    price = p.price
    p.image1=i1
    p.image2=i2
    p.name=name
    p.price=price
    description = p.description
    p.save()
    # return redirect("/viewProduct/")
    return render(request, 'viewProduct.html', {'p': p})


def addcart(request,pid):
    user=request.user.id
    # print(user)
    proid=Product.objects.get(id=pid)
    # print(proid)
    if cart.objects.filter(user=user,product=proid.id):
        c=cart.objects.get(user=user,product=proid.id)
        print(c.quantity)
        c.quantity = int(c.quantity) + 1
        c.total=c.quantity * c.total
        c.save()
        print(c.quantity)
        return  redirect('/cart/')

    else:
        p = cart.objects.create(user_id=user,total=proid.price, product_id=proid.id)
        return redirect('/cart/')


    return render(request,'cart.html')

def viewcart(request):
    user = request.user.id
    c = cart.objects.filter(user=user)
    product_count = c.count()
    total=0

    # print(c)
    if not c:
        messages.error(request,"Your cart is empty please check product")

    else:

        total = sum(i.total for i in c)
        return render(request, 'cart.html', {'c': c, 'total': total, 'product_count': product_count})


    return render(request,'cart.html',{'c':c,'total':total})



def deleteCart(request,id):
    c = cart.objects.get(id=id)
    c.delete()
    return redirect('/cart/')

def checkout(request):
        user = request.user.id
        cart_items = cart.objects.filter(user=user)
        total = sum(item.total for item in cart_items)
        return render(request, 'checkout.html', {'cart_items': cart_items, 'total': total})


def changeqty(request,id):
    c=cart.objects.get(id=id)
    print(c,'cccccccccccccc')
    new_quantity = request.POST['qty']
    print(new_quantity,'nq')
    if new_quantity == 0:
        c.delete()
        return redirect('/cart/')
    else:    # Get the updated quantity from the form
        c.quantity = new_quantity
        c.total = c.product.price * int(new_quantity)
        c.save()
        return redirect('/cart/')


