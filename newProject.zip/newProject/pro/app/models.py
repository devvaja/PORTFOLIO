from django.contrib.auth.models import User
from django.db import models
from django.utils.timezone import *

CHOICES = [
    ('instock', 'instock'),
    ('outstock', 'outstock'),

]
class Product(models.Model):
    name = models.CharField(max_length=50)
    description = models.CharField(max_length=100)
    price = models.IntegerField()
    quantity = models.IntegerField()
    createDate = models.DateTimeField(auto_now_add=True)
    image1 = models.ImageField()
    image2 = models.ImageField()
    status=models.CharField(max_length=50,choices=CHOICES)



class cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True)
    quantity = models.CharField(max_length=50,default=1)
    total = models.IntegerField()


class Order(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    address = models.CharField(max_length=50)
    city = models.CharField(max_length=50)
    pin = models.IntegerField()
    status = models.CharField(max_length=50)
